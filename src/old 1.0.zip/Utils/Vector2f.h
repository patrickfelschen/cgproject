//
// Created by Patrick on 15.07.2022.
//

#ifndef CG_VECTOR2F_H
#define CG_VECTOR2F_H


class Vector2f {
public:
    float X;
    float Y;

    Vector2f(float x, float y);

    Vector2f();
};


#endif //CG_VECTOR2F_H
