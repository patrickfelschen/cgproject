//
// Created by Patrick on 15.07.2022.
//

#ifndef CG_RESOURCEMANAGER_H
#define CG_RESOURCEMANAGER_H


#include <vector>

class ResourceManager {
public:
    std::vector<unsigned char> ResourceManager::loadTextureFromFile(const char* texturePath, unsigned int& width, unsigned int& height);

};


#endif //CG_RESOURCEMANAGER_H
