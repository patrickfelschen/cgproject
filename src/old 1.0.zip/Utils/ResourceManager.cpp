//
// Created by Patrick on 15.07.2022.
//

#include "ResourceManager.h"

std::vector<unsigned char> ResourceManager::loadTextureFromFile(const char* texturePath, unsigned int& width, unsigned int& height)
{
    // Pr�fe den Dateityp, ob es sich um eine BitMap handelt
    FREE_IMAGE_FORMAT imageFormat = FreeImage_GetFileType(texturePath, 0);

    if (imageFormat == FIF_UNKNOWN)
    {
        imageFormat = FreeImage_GetFIFFromFilename(texturePath);
    }
    if (imageFormat == FIF_UNKNOWN)
    {
        std::cout << "WARNING::MODEL::Unbekanntes Dateiformat der Textur!" << std::endl;
    }
    FIBITMAP* pBitMap = FreeImage_Load(imageFormat, texturePath);
    if (pBitMap == nullptr)
    {
        std::cout << "ERROR::MODEL::Dateiformat der Textur kann nicht ge�ffnet werden!" << std::endl;
        return std::vector<unsigned char>();
    }

    FREE_IMAGE_TYPE type = FreeImage_GetImageType(pBitMap);
    assert(type == FIT_BITMAP);

    // Lese die Breite, H�he und Bit pro Pixel der Datei aus.
    width = FreeImage_GetWidth(pBitMap);
    height = FreeImage_GetHeight(pBitMap);
    unsigned int bpp = FreeImage_GetBPP(pBitMap);
    assert(bpp == 16 || bpp == 24 || bpp == 32);

    // Speicherplatz f�r alle Pixel erstellen
    std::vector<unsigned char> imageData; // = std::vector<unsigned char>(width * height * 4);

    RGBQUAD color;
    // Pixel Farbe auslesen und abspeichern
    for (unsigned int i = 0; i < height; i++)
    {
        for (unsigned int j = 0; j < width; j++)
        {
            FreeImage_GetPixelColor(pBitMap, j, height - i - 1, &color);
            imageData.push_back(color.rgbRed);
            imageData.push_back(color.rgbGreen);
            imageData.push_back(color.rgbBlue);
            if (bpp == 32)
            {
                imageData.push_back(color.rgbReserved);
            }
            else
            {
                imageData.push_back(255);
            }
        }
    }

    // Speicherplatz freigeben
    FreeImage_Unload(pBitMap);

    return imageData;
}