//
// Created by Patrick on 15.07.2022.
//

#include "Vector2f.h"

Vector2f::Vector2f(float x, float y) {
    this->X = x;
    this->Y = y;
}

Vector2f::Vector2f() {
    this->X = 0;
    this->Y = 0;
}
