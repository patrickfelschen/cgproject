//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_APPLICATION_H
#define CG_APPLICATION_H


#include "GLFW/glfw3.h"

class Application {
public:
    explicit Application(GLFWwindow& glfWwindow);
    virtual ~Application();
    void start();
    void update(float dtime);
    void draw();
    void end();
private:
    GLFWwindow& glfWwindow;
};

#endif //CG_APPLICATION_H
