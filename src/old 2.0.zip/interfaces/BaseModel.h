//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_BASEMODEL_H
#define CG_BASEMODEL_H

#include "BaseCamera.h"
#include "BaseShader.h"

class BaseModel {
public:
    BaseModel();
    virtual ~BaseModel();
    virtual void draw(const BaseCamera& camera);
    const Matrix &getTransform() const;
    BaseShader &getShader() const;
protected:
    Matrix transform;
    BaseShader& shader;
};

#endif //CG_BASEMODEL_H
