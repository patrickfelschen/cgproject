//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_BASECAMERA_H
#define CG_BASECAMERA_H

#include "../maths/Matrix.h"
#include "../maths/Vector3f.h"

class BaseCamera {
public:
    virtual ~BaseCamera() = default;
    virtual void update() = 0;
    virtual const Matrix& getViewMatrix() = 0;
    virtual const Matrix& getProjectionMatrix() = 0;
    virtual const Vector3f position() const = 0;
};

#endif //CG_BASECAMERA_H
