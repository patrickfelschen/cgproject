//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_BASESHADER_H
#define CG_BASESHADER_H

#include "../maths/Matrix.h"
#include "GL/glew.h"
#include "BaseCamera.h"

class BaseShader {
public:
    BaseShader();
    virtual ~BaseShader();

    virtual void modelTransform(const Matrix& transform);
    virtual void activate(const BaseCamera& camera) const;
    virtual void deactivate() const;

    // Setter für Uniform Parameter
    void setParameter(const char* name, float parameter) const;
    void setParameter(const char* name, int parameter) const;
    void setParameter(const char* name, const Vector3f parameter) const;
    void setParameter(const char* name, const Matrix& parameter) const;

    // Getter
    const Matrix &getTransform() const;
    GLuint getShaderProgramId() const;

protected:
    Matrix transform;
    GLuint shaderProgram;
private:
    GLuint getParameterId(const char* name) const;
};

#endif //CG_BASESHADER_H
