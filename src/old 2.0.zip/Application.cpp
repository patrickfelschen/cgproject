//
// Created by Patrick on 01.08.2022.
//

#include <iostream>
#include "Application.h"

/**
 * TODO
 * @param glfWwindow
 */
Application::Application(GLFWwindow &glfWwindow) : glfWwindow(glfWwindow) {}

/**
 *  TODO
 */
Application::~Application() {

}

/**
 * TODO
 */
void Application::start() {
    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LESS);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glEnable(GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

/**
 * TODO
 * @param dtime
 */
void Application::update(float dtime) {

}

/**
 * TODO
 */
void Application::draw() {
    // 1.) Clear screen
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // 2.) Setup shaders and draw Models
    // 3.) Check for OpenGL errors
}

/**
 * TODO
 */
void Application::end() {

}
