//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_NODE_H
#define CG_NODE_H


class Node {

};


#endif //CG_NODE_H
