//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_MESH_H
#define CG_MESH_H


#include "Vertex.h"
#include "Texture.h"

class Mesh {
public:
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;
    std::vector<Texture> textures;

    Mesh();

    Mesh(const std::vector<Vertex> &vertices, const std::vector<unsigned int> &indices,
         const std::vector<Texture> &textures);

    ~Mesh();

    void addVertex(const Vertex& vertex);
};


#endif //CG_MESH_H
