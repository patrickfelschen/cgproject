//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_TEXTURE_H
#define CG_TEXTURE_H


#include <vector>

class Texture {
public:
    unsigned int width;
    unsigned int height;
    std::vector<unsigned char> &imageData;
    Texture();
    virtual ~Texture();
};


#endif //CG_TEXTURE_H
