//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_VERTEX_H
#define CG_VERTEX_H


#include "../maths/Vector3f.h"
#include "../maths/Vector2f.h"

class Vertex {
public:
    Vector3f position;
    Vector3f normal;
    Vector2f texCoords;
};


#endif //CG_VERTEX_H
