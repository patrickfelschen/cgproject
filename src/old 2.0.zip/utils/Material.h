//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_MATERIAL_H
#define CG_MATERIAL_H


class Material {

};


#endif //CG_MATERIAL_H
