//
// Created by Patrick on 01.08.2022.
//

#include "Mesh.h"

void Mesh::addVertex(const Vertex& vertex) {
    this->vertices.push_back(vertex);
}
