//
// Created by Patrick on 15.07.2022.
//

#include "Vector2f.h"

Vector2f::Vector2f(float x, float y) {
    this->x = x;
    this->y = y;
}

Vector2f::Vector2f() {
    this->x = 0;
    this->y = 0;
}
