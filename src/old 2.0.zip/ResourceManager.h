//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_RESOURCEMANAGER_H
#define CG_RESOURCEMANAGER_H

#include <vector>
#include <cassert>
#include "sstream"
#include <fstream>
#include "models/Model.h"
#include "FreeImage.h"
#include "utils/Texture.h"
#include <assimp/cimport.h>
#include <assimp/scene.h>
#include <assimp/postprocess.h>


/**
 * Singleton ResourceManager
 * https://stackoverflow.com/a/1008289
 */
class ResourceManager {
public:
    static ResourceManager &getInstance() {
        static ResourceManager instance;
        return instance;
    }

    ResourceManager(ResourceManager const &) = delete;
    void operator=(ResourceManager const &) = delete;

    // Textur aus Datei laden
    void loadTexture(const char* filePath, Texture& loadedTexture);

    // Shader aus Datei laden
    void loadShader(const char* filePath, std::string& loadedShader);

    // Model mit Assimp aus Objekt Datei lesen
    void loadMeshes(const char* filePath, std::vector<Mesh>& loadedMeshes);
    void loadMaterials(const char* filePath, std::vector<Material>& loadedMaterials);
    void loadNodes(const char* filePath, std::vector<Node>& loadedNodes);

private:
    ResourceManager() = default;
};

#endif //CG_RESOURCEMANAGER_H