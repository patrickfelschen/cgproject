#include <iostream>
#include "GL/glew.h"
#include "GLFW/glfw3.h"
#include "Application.h"

//
// Created by Patrick on 01.08.2022.
//
int main() {

    if (!glfwInit()) {
        std::cerr << "ERROR: could not start GLFW3" << std::endl;
        return EXIT_FAILURE;
    }

#ifdef __APPLE__
    glfwWindowHint (GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint (GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint (GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint (GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

    const int WINDOW_WIDTH = 800;
    const int WINDOWS_HEIGHT = 600;

    GLFWwindow *glfwWindow = glfwCreateWindow(
            WINDOW_WIDTH,
            WINDOWS_HEIGHT,
            "Computergrafik - Hochschule Osnabrück",
            nullptr, nullptr
    );

    if(!glfwWindow){
        std::cerr << "ERROR: can not open window with GLFW" << std::endl;
        glfwTerminate();
        return EXIT_FAILURE;
    }

    glfwMakeContextCurrent(glfwWindow);

#if WIN32
    glewExperimental = GL_TRUE;
    glewInit();
#endif

    double lastTime = 0;
    Application App(*glfwWindow);
    App.start();
    while(!glfwWindowShouldClose(glfwWindow)){
        double now = glfwGetTime();
        double dtime = now - lastTime;
        lastTime = now;

        glfwPollEvents();
        App.update((float) dtime);
        App.draw();
    }
    App.end();
    glfwTerminate();
    return EXIT_SUCCESS;
}