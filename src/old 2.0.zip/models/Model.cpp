//
// Created by Patrick on 01.08.2022.
//

#include "Model.h"

Model::Model() {

}

Model::~Model() {

}

void Model::draw(BaseCamera &camera) {

}
