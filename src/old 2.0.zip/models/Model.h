//
// Created by Patrick on 01.08.2022.
//

#ifndef CG_MODEL_H
#define CG_MODEL_H


#include <vector>
#include "../interfaces/BaseModel.h"
#include "../utils/Mesh.h"
#include "../utils/Material.h"
#include "../utils/Node.h"

class Model : public BaseModel{
public:
    Model();
    virtual ~Model();
    virtual void draw(BaseCamera& camera);
protected:
    std::vector<Mesh> meshes;
    std::vector<Material> materials;
    Node rootNode;
};


#endif //CG_MODEL_H
