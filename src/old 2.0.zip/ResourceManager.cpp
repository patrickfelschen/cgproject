//
// Created by Patrick on 01.08.2022.
//

#include "ResourceManager.h"
#include "utils/Vertex.h"

void ResourceManager::loadTexture(const char *filePath, Texture& loadedTexture) {
    // Prüfe den Dateityp, ob es sich um eine BitMap handelt
    FREE_IMAGE_FORMAT imageFormat = FreeImage_GetFileType(filePath, 0);

    if (imageFormat == FIF_UNKNOWN) {
        imageFormat = FreeImage_GetFIFFromFilename(filePath);
    }
    if (imageFormat == FIF_UNKNOWN) {
        std::cout << "WARNING::Unbekanntes Dateiformat der Textur!" << std::endl;
    }
    FIBITMAP *pBitMap = FreeImage_Load(imageFormat, filePath);
    if (pBitMap == nullptr) {
        std::cout << "ERROR::Dateiformat der Textur kann nicht geöffnet werden!" << std::endl;
        exit(EXIT_FAILURE);
    }

    FREE_IMAGE_TYPE type = FreeImage_GetImageType(pBitMap);
    assert(type == FIT_BITMAP);

    // Lese die Breite, Höhe und Bit pro Pixel der Datei aus.
    unsigned int width = FreeImage_GetWidth(pBitMap);
    unsigned int height = FreeImage_GetHeight(pBitMap);
    unsigned int bpp = FreeImage_GetBPP(pBitMap);
    assert(bpp == 16 || bpp == 24 || bpp == 32);

    // Speicherplatz für alle Pixel erstellen
    std::vector<unsigned char> imageData; // = std::vector<unsigned char>(width * height * 4);

    RGBQUAD color;
    // Pixel Farbe auslesen und abspeichern
    for (unsigned int i = 0; i < height; i++) {
        for (unsigned int j = 0; j < width; j++) {
            FreeImage_GetPixelColor(pBitMap, j, height - i - 1, &color);
            imageData.push_back(color.rgbRed);
            imageData.push_back(color.rgbGreen);
            imageData.push_back(color.rgbBlue);
            if (bpp == 32) {
                imageData.push_back(color.rgbReserved);
            } else {
                imageData.push_back(255);
            }
        }
    }

    // Speicherplatz freigeben
    FreeImage_Unload(pBitMap);

    loadedTexture.width = width;
    loadedTexture.height = height;
    loadedTexture.imageData = imageData;
}

void ResourceManager::loadShader(const char *filePath, std::string& loadedShader) {
    std::ifstream stream(filePath);
    std::string line;
    std::stringstream sstream;
    if (!stream.is_open()) {
        std::cerr << "ERROR::Shader " << filePath << " nicht gefunden!" << std::endl;
        exit(EXIT_FAILURE);
    }
    while (getline(stream, line)) {
        sstream << line << "\n";
    }
    stream.close();
    loadedShader = sstream.str();
}

void ResourceManager::loadMeshes(const char *filePath, std::vector<Mesh> &loadedMeshes) {
    const aiScene* pScene = aiImportFile(filePath, aiProcessPreset_TargetRealtime_Fast | aiProcess_TransformUVCoords);
    if (pScene == nullptr || pScene->mNumMeshes <= 0) return;

    for (unsigned int i = 0; i < pScene->mNumMeshes; i++) {
        aiMesh* mesh = pScene->mMeshes[i];
        std::vector<Vertex> vertices;
        std::vector<unsigned int> indices;

        for (unsigned int j = 0; j < mesh->mNumVertices; j++) {
            Vertex vertex;

            if(mesh->HasNormals()) {
                aiVector3D v = mesh->mNormals[j];
                vertex.normal.x = v.x;
                vertex.normal.y = v.y;
                vertex.normal.z = v.z;
            }

            if(mesh->HasPositions()) {
                aiVector3D v = mesh->mVertices[j];
                vertex.position.x = v.x;
                vertex.position.y = v.y;
                vertex.position.z = v.z;
            }

            if (mesh->HasTextureCoords(0)) {
                aiVector3D v = mesh->mTextureCoords[0][j];
                vertex.texCoords.x = v.x;
                vertex.texCoords.y = v.y;
            }

            vertices.push_back(vertex);
        }

        for (unsigned int j = 0; j < mesh->mNumFaces; j++) {
            aiFace face = mesh->mFaces[j];
            for (unsigned int u = 0; u < face.mNumIndices; u++) {
                indices.push_back(face.mIndices[u]);
            }
        }

        pMeshes[i].MaterialIdx = mesh->mMaterialIndex;
    }

}

