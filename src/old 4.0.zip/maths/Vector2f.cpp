//
// Created by Patrick on 03.08.2022.
//

#include "Vector2f.h"

Vector2f::Vector2f(float x, float y) : x(x), y(y) {}

Vector2f::Vector2f() : x(0), y(0) {}