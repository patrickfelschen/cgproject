//
// Created by Patrick on 12.08.2022.
//

#ifndef CG_TERRAINMODEL_H
#define CG_TERRAINMODEL_H


#include "../shaders/AbstractShader.h"
#include "AbstractModel.h"

class TerrainModel : public AbstractModel {
public:
    explicit TerrainModel(AbstractShader *shader);

    ~TerrainModel() override = default;

    void update(float deltaTime) const override;

    void render(const Camera &camera, const Matrix &transform) const override;

private:
    float width;
    float height;
    float depth;

    void generate();
};


#endif //CG_TERRAINMODEL_H
