//
// Created by Patrick on 04.08.2022.
//

#ifndef CG_ABSTRACTMODEL_H
#define CG_ABSTRACTMODEL_H


#include "../maths/Matrix.h"
#include "../utils/Camera.h"
#include "../shaders/AbstractShader.h"
#include "../utils/Mesh.h"
#include "../utils/Aabb.h"

class AbstractModel {
public:
    AbstractModel();

    virtual ~AbstractModel();

    virtual void render(const Camera &camera) const = 0;

    void setBoundingBox();

    const AABB &getBoundingBox() const;

protected:
    std::vector<Mesh> meshes;

private:
    AABB boundingBox;
    void drawBoundingBox() const;
};


#endif //CG_ABSTRACTMODEL_H
