//
// Created by Patrick on 01.08.2022.
//

#include "Game.h"
#include "shaders/PhongShader.h"
#include "entities/GunEntity.h"
#include "entities/CoinEntity.h"
#include "models/TerrainModel.h"
#include "shaders/TerrainShader.h"

#define TARGET_COUNT 20

AbstractModel *garageModel;
AbstractModel *gunModel;
AbstractModel *coinModel;
AbstractModel *skyboxModel;
AbstractModel *terrainModel;

GunEntity *gunEntity;
AbstractEntity *garageEntity1;
AbstractEntity *garageEntity2;
AbstractEntity *garageEntity3;
AbstractEntity *garageEntity4;
AbstractEntity *skyboxEntity;
AbstractEntity *terrainEntity;

unsigned int hitCount = 0;

Game::Game(GLFWwindow &window, const Camera &camera) : window(window), camera(camera) {
    garageModel = new ObjectModel(new PhongShader(), "../assets/Objects/Garage/MUW04SKJGJ052IRMJUCT9DJ5E.obj");
    gunModel = new ObjectModel(new PhongShader(false), "../assets/Objects/Gun/ZE8FK2UU5PF8Y5F5777X34XII.obj");
    coinModel = new ObjectModel(new PhongShader(), "../assets/Objects/Coin/I89O58TBZ353I4X9ANHTRFF5K.obj");
    skyboxModel = new ObjectModel(new PhongShader(), "../assets/Objects/SkyBox/skybox.obj");
    terrainModel = new TerrainModel(new TerrainShader());

    // Himmel
    skyboxEntity = new AbstractEntity(skyboxModel);

    // Umgebung
    terrainEntity = new AbstractEntity(terrainModel);
    //terrainEntity->setPosition(0, -0.5, 0);

    // Waffe
    gunEntity = new GunEntity(gunModel, window);

    // Garagen
    garageEntity1 = new AbstractEntity(garageModel);
    garageEntity1->setScaling(2.0f);
    garageEntity1->setPosition(3, 1, 3);

    garageEntity2 = new AbstractEntity(garageModel);
    garageEntity2->setScaling(2.0f);
    garageEntity2->setPosition(-3, 1, 3);
    garageEntity2->setRotationY(180);

    garageEntity3 = new AbstractEntity(garageModel);
    garageEntity3->setScaling(2.0f);
    garageEntity3->setPosition(3, 1, -3);

    garageEntity4 = new AbstractEntity(garageModel);
    garageEntity4->setScaling(2.0f);
    garageEntity4->setPosition(-3, 1, -3);
    garageEntity4->setRotationY(180);

    entities.push_back(gunEntity);
    entities.push_back(garageEntity1);
    entities.push_back(garageEntity2);
    entities.push_back(garageEntity3);
    entities.push_back(garageEntity4);
    entities.push_back(skyboxEntity);
    entities.push_back(terrainEntity);

    // Ziele
    for (unsigned int i = 0; i < TARGET_COUNT; i++) {
        targets.push_back(new CoinEntity(coinModel));
    }

    gunEntity->setTargets(targets);

    srand(time(nullptr));
}

Game::~Game() {

}

void Game::update(float deltaTime) {
    // Kamera aktualisieren
    camera.update(deltaTime);
    // Alle Ziele aktualisieren
    for (CoinEntity *entity: targets) {
        if (entity->hit) {
            entity->respawn(camera.getPosition());
            hitCount++;
            std::cout << "Treffer: " << hitCount << std::endl;
        }
        entity->update(deltaTime);
    }
    // Alle Einheiten aktualisieren
    for (AbstractEntity *entity: entities) {
        entity->update(deltaTime);
    }
}

void Game::render() {
    // Alle Ziele zeichnen
    for (CoinEntity *entity: targets) {
        entity->render(camera);
    }
    // Alle Einheiten zeichnen
    for (AbstractEntity *entity: entities) {
        entity->render(camera);
    }
}
