//
// Created by Patrick on 04.08.2022.
//

#ifndef CG_ABSTRACTENTITY_H
#define CG_ABSTRACTENTITY_H


#include "../models/ObjectModel.h"

class AbstractEntity {
public:
    explicit AbstractEntity(const AbstractModel *model);

    virtual ~AbstractEntity();

    virtual void update(float deltaTime);

    virtual void render(const Camera &camera) = 0;

    void setPosition(const Vector3f &pos);

    void setRotationX(float newRotationX);

    void setRotationY(float newRotationY);

    void setRotationZ(float newRotationZ);

    void setScaling(float newScaling);

    const Vector3f &getPosition() const;

    const Vector3f &getVelocity() const;

    float getRotAngleX() const;

    float getRotAngleY() const;

    float getRotAngleZ() const;

    float getScaleFactor() const;

    AABB getTransformedBoundingBox() const;

protected:
    const AbstractModel *model;

    Vector3f position;
    Vector3f velocity;

    Matrix transformation;

    float rotAngleX;
    float rotAngleY;
    float rotAngleZ;
    float scaleFactor;
};


#endif //CG_ABSTRACTENTITY_H
