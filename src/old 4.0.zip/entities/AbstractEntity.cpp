//
// Created by Patrick on 04.08.2022.
//

#include "AbstractEntity.h"
#define TO_RAD(deg) (deg * std::numbers::pi / 180.0)

AbstractEntity::AbstractEntity(const AbstractModel *model) : model(model) {
    this->position = Vector3f();
    this->velocity = Vector3f();
    this->scaleFactor = 1.0;
    this->rotAngleX = 0;
    this->rotAngleY = 0;
    this->rotAngleZ = 0;
}

AbstractEntity::~AbstractEntity() = default;

void AbstractEntity::update(float deltaTime) {
    // AbstractEntity in Richtung bewegen, falls eine
    // Geschwindigkeit existiert
    position.x += deltaTime * velocity.x;
    position.y += deltaTime * velocity.y;
    position.z += deltaTime * velocity.z;

    // Transformation erstellen
    Matrix translation, rotationX, rotationY, rotationZ, scaling;

    translation.translation(this->position);
    rotationX.rotationX(TO_RAD(this->rotAngleX));
    rotationY.rotationY(TO_RAD(this->rotAngleY));
    rotationZ.rotationZ(TO_RAD(this->rotAngleZ));
    scaling.scale(this->scaleFactor);

    this->transformation = translation * rotationX * rotationY * rotationZ * scaling;
}

void AbstractEntity::setPosition(const Vector3f &pos) {
    this->position = pos;
}

void AbstractEntity::setRotationX(float newRotationX) {
    this->rotAngleX = newRotationX;
}

void AbstractEntity::setRotationY(float newRotationY) {
    this->rotAngleY = newRotationY;
}

void AbstractEntity::setRotationZ(float newRotationZ) {
    this->rotAngleZ = newRotationZ;
}

void AbstractEntity::setScaling(float newScaling) {
    this->scaleFactor = newScaling;
}

const Vector3f &AbstractEntity::getPosition() const {
    return position;
}

const Vector3f &AbstractEntity::getVelocity() const {
    return velocity;
}

float AbstractEntity::getRotAngleX() const {
    return rotAngleX;
}

float AbstractEntity::getRotAngleY() const {
    return rotAngleY;
}

float AbstractEntity::getRotAngleZ() const {
    return rotAngleZ;
}

float AbstractEntity::getScaleFactor() const {
    return scaleFactor;
}

AABB AbstractEntity::getTransformedBoundingBox() const {
    return model->getBoundingBox().transform(transformation);
}
