//
// Created by Patrick on 19.08.2022.
//

#include "ParticleManager.h"
#include "ParticleModel.h"

ParticleManager::ParticleManager(unsigned int numParticles){
    this->numParticles = numParticles;
    auto *particleModel = new ParticleModel(new AbstractShader()); // TODO: ParticleShader
    for(unsigned int i = 0; i < numParticles; i++){
        particles.push_back(new ParticleEntity(particleModel));
    }
}

ParticleManager::~ParticleManager() {
    for(auto & particel: particles){
        delete particel;
    }
}

void ParticleManager::update(const Vector3f &position, float deltaTime) {
    for(auto &p : particles) {
        unsigned int unusedParticle = firstUnusedParticle();
        respawnParticle(particles[unusedParticle], position, Vector3f(0.0f, 0.0f, -1.0f));
    }
    for(auto &p : particles) {
        p->setLife(p->getLife() - deltaTime);
        if(p->getLife() > 0.0f) {
            p->setPosition(p->getPosition() - p->getVelocity() * deltaTime);
            p->setAlpha(p->getColor().a - deltaTime);
            printf("Alpha: %f\n", p->getColor().a);
        }
    }
}

void ParticleManager::render(const Camera &camera) {
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    for(auto &p : particles) {
        if(p->getLife() > 0.0f) {
//            shader->setUniform("offset", p.getPosition());
//            shader->setUniform("color", p.getColor().r, p.getColor().g, p.getColor().b, p.getColor().a);
            p->render(camera);
        }
    }
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

unsigned int ParticleManager::firstUnusedParticle() {
    for(unsigned int i = lastUsedParticle; i < numParticles; i++) {
        if(particles[i]->getLife() <= 0.0f) {
            lastUsedParticle = i;
            return i;
        }
    }
    lastUsedParticle = 0;
    return 0;
}

void ParticleManager::respawnParticle(ParticleEntity *particle, const Vector3f &position, Vector3f offset) {
    float random = rndFloat(-1.0f, 1.0f);
    float rColor = 0.5f + ((rand() % 100) / 100.0f);
    particle->setPosition(Vector3f(0.026, -0.015, -0.045));
    particle->setColor(Color(rColor, rColor, rColor, 1.0f));
    particle->setLife(2.0f);
    particle->setVelocity(Vector3f(rndFloat(-0.025f, 0.025f), rndFloat(-0.025f, 0.025f), rndFloat(0.2f, 3.0f)));
}

float ParticleManager::rndFloat(float min, float max) {
    return ((float(rand()) / float(RAND_MAX)) * (max - min)) + min;
}




