//
// Created by Patrick on 19.08.2022.
//

#ifndef CG_PARTICLEMODEL_H
#define CG_PARTICLEMODEL_H


#include "../../models/AbstractModel.h"
#include "../../utils/Vertex.h"

class ParticleModel : public AbstractModel {
public:
    explicit ParticleModel(AbstractShader *shader);

    ~ParticleModel() override;

    void update(float deltaTime) const override;

    void render(const Camera &camera) const override;

    void setOffset(const Vector3f &offset);

    void setColor(const Color &color);

    void setTransform(const Matrix &transform);

private:
    Matrix transform;
    Vector3f offset;
    Color color;
};


#endif //CG_PARTICLEMODEL_H
