//
// Created by Patrick on 19.08.2022.
//

#include "ParticleEntity.h"

ParticleEntity::ParticleEntity(const AbstractModel *model) : AbstractEntity(model) {
    this->life = 10.0f;
    this->color = Color(1.0f);
}

ParticleEntity::~ParticleEntity() = default;

const Color &ParticleEntity::getColor() const {
    return color;
}

void ParticleEntity::setColor(const Color &color) {
    this->color = color;
}

float ParticleEntity::getLife() const {
    return life;
}

void ParticleEntity::setLife(float life) {
    this->life = life;
}

void ParticleEntity::setAlpha(float v) {
    color.a = v;
}

void ParticleEntity::render(const Camera &camera) {
    this->model->render(camera);
}

void ParticleEntity::update(float deltaTime) {
    AbstractEntity::update(deltaTime);
}
