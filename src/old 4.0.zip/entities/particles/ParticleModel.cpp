//
// Created by Patrick on 19.08.2022.
//

#include "ParticleModel.h"

ParticleModel::ParticleModel(AbstractShader *shader) : AbstractModel(shader) {
    std::vector<unsigned int> indices =
            {
                    0, 1, 3, 3, 1, 2,
                    1, 5, 2, 2, 5, 6,
                    5, 4, 6, 6, 4, 7,
                    4, 0, 7, 7, 0, 3,
                    3, 2, 7, 7, 2, 6,
                    4, 5, 0, 0, 5, 1
            };
    std::vector<Vertex> vertices = {
            Vertex(Vector3f(-1, -1, -1), Vector3f(), Vector2f(0, 0), Vector2f()),
            Vertex(Vector3f(1, -1, -1), Vector3f(), Vector2f(1, 0), Vector2f()),
            Vertex(Vector3f(1, 1, -1), Vector3f(), Vector2f(1, 1), Vector2f()),
            Vertex(Vector3f(-1, 1, -1), Vector3f(), Vector2f(0, 1), Vector2f()),
            Vertex(Vector3f(-1, -1, 1), Vector3f(), Vector2f(0, 0), Vector2f()),
            Vertex(Vector3f(1, -1, 1), Vector3f(), Vector2f(1, 0), Vector2f()),
            Vertex(Vector3f(1, 1, 1), Vector3f(), Vector2f(1, 1), Vector2f()),
            Vertex(Vector3f(-1, 1, 1), Vector3f(), Vector2f(0, 1), Vector2f()),
    };
    std::vector<Texture> textures = {
            //Texture("../assets/Textures/fire.png", "")
            Texture()
    };
    this->meshes.push_back(Mesh(vertices, indices, textures, Material()));
    //this->setBoundingBox();
}

ParticleModel::~ParticleModel() = default;

void ParticleModel::update(float deltaTime) const {
    AbstractModel::update(deltaTime);
}

void ParticleModel::setOffset(const Vector3f &offset) {
    this->offset = offset;
}

void ParticleModel::setColor(const Color &color) {
    this->color = color;
}

void ParticleModel::setTransform(const Matrix &transform) {
    this->transform = transform;
}

void ParticleModel::render(const Camera &camera) const {
    // AbstractShader Uniforms setzen
    this->shader->activate(camera);
    this->shader->setUniform("uTransform", this->transform);
    // Particel Uniforms setzen
    this->shader->setUniform("uColor", this->color);
    this->shader->setUniform("uOffset", this->offset);
    this->shader->setTransform(transform);

    for (auto &mesh: meshes) {
        mesh.render(shader);
    }

    this->shader->deactivate();
}
