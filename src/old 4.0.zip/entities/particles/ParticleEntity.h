//
// Created by Patrick on 19.08.2022.
//

#ifndef CG_PARTICLEENTITY_H
#define CG_PARTICLEENTITY_H


#include "../AbstractEntity.h"

class ParticleEntity : public AbstractEntity {
public:
    explicit ParticleEntity(const AbstractModel *model);

    ~ParticleEntity() override;

    const Color &getColor() const;

    void setColor(const Color &color);

    float getLife() const;

    void setLife(float life);

    void setAlpha(float v);

    void update(float deltaTime) override;

    void render(const Camera &camera) override;

protected:
    Color color;
    float life;
};


#endif //CG_PARTICLEENTITY_H
