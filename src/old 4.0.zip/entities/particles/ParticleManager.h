//
// Created by Patrick on 19.08.2022.
//

#ifndef CG_PARTICLEMANAGER_H
#define CG_PARTICLEMANAGER_H


#include <vector>
#include "ParticleEntity.h"

class ParticleManager {
public:
    explicit ParticleManager(unsigned int numParticles);

    virtual ~ParticleManager();

    void update(const Vector3f &position, float deltaTime);

    void render(const Camera &camera);

private:
    std::vector<ParticleEntity *> particles;

    unsigned int numParticles = 0;

    unsigned int lastUsedParticle = 0;

    unsigned int firstUnusedParticle();

    void respawnParticle(ParticleEntity *particle, const Vector3f &position, Vector3f offset);

    float rndFloat(float min, float max);
};


#endif //CG_PARTICLEMANAGER_H
