//
// Created by Patrick on 02.08.2022.
//

#ifndef CG_ABSTRACTSHADER_H
#define CG_ABSTRACTSHADER_H


#include <unordered_map>
#include "GL/glew.h"
#include "../utils/Loader.h"
#include "../maths/Vector3f.h"
#include "../maths/Matrix.h"
#include "../utils/Camera.h"
#include "../utils/Color.h"

/**
 * Basisklasse für Shader
 */
class AbstractShader {
public:
    explicit AbstractShader(const char *vsFilePath, const char *fsFilePath);

    virtual ~AbstractShader();

    void activate(const Camera &camera);

    void deactivate() const;

    void setUniform(const std::string &name, int value);

    void setUniform(const std::string &name, float value);

    void setUniform(const std::string &name, const Vector3f &value);

    void setUniform(const std::string &name, const Color &value);

    void setUniform(const std::string &name, const Matrix &value);

protected:
    virtual void setUniforms(const Camera &camera) = 0;

private:
    // ID des shaders
    GLuint id = 0;
    // Pfad der Vertex Shader Datei
    const char *vsFilePath;
    // Pfad der Fragment Shader Datei
    const char *fsFilePath;
    // Uniform Location ID über Namen bekommen
    GLint getUniformLocation(const std::string &name);
    // Cache Speicher für Uniform Location IDs
    std::unordered_map<std::string, GLint> uniformLocationCache;

    void compileShaders();

    void addShader(const char *shaderText, GLenum shaderType) const;
};


#endif //CG_ABSTRACTSHADER_H
