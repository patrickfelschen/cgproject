//
// Created by Patrick on 05.08.2022.
//

#ifndef CG_PHONGSHADER_H
#define CG_PHONGSHADER_H


#include "AbstractShader.h"

class PhongShader : public AbstractShader {
public:
    PhongShader();

    ~PhongShader() override;

    void setTransform(const Matrix &t);

    void setView(const Matrix &v);

    void setProjection(const Matrix &p);

protected:
    Matrix transform;
    Matrix view;
    Matrix projection;

    void setUniforms(const Camera &camera) override;
};


#endif //CG_PHONGSHADER_H
