//
// Created by Patrick on 05.08.2022.
//

#include "PhongShader.h"

#define VERT "../assets/shaders/phongShader.vert"
#define FRAG "../assets/shaders/phongShader.frag"

PhongShader::PhongShader() : AbstractShader(VERT, FRAG) {
    this->projection.identity();
    this->view.identity();
    this->transform.identity();
}

void PhongShader::setUniforms(const Camera &camera) {
    // AbstractModel View Projection
    setUniform("uProjection", projection);
    setUniform("uView", view);
    setUniform("uTransform", transform);
    // Kamera Position
    setUniform("uCamPos", camera.getPosition());
    // Licht
    Vector3f lightPos = Vector3f(-3.0f, 10.0f, 0.0f);
    Color light = Color(1.0f, 1.0f, 1.0f);
    Color lightDiffuse = light * 0.8;
    Color lightAmbient = lightDiffuse * 0.7f;
    Color lightSpecular = Color(1.0f, 1.0f, 1.0f);

    setUniform("uLight.position", lightPos);
    setUniform("uLight.ambient", lightAmbient);
    setUniform("uLight.diffuse", lightDiffuse);
    setUniform("uLight.specular", lightSpecular);
}

void PhongShader::setTransform(const Matrix &t) {
    this->transform = t;
}

void PhongShader::setView(const Matrix &v) {
    this->view = v;
}

void PhongShader::setProjection(const Matrix &p) {
    this->projection = p;
}

PhongShader::~PhongShader() = default;
