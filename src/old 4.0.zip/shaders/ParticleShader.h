//
// Created by Patrick on 24.08.2022.
//

#ifndef CG_PARTICLESHADER_H
#define CG_PARTICLESHADER_H


#include "AbstractShader.h"

class ParticleShader : public AbstractShader {
public:
    ParticleShader();

    ~ParticleShader() override;

    void setOffset(const Vector3f &offset);

    void setColor(const Color &color);

    void setTransform(const Matrix& transform);

protected:
    void setUniforms(const Camera &camera) override;

private:
    Matrix transform;
    Vector3f offset;
    Color color;
};


#endif //CG_PARTICLESHADER_H
