//
// Created by Patrick on 24.08.2022.
//

#include "ParticleShader.h"

#define VERT "../assets/shaders/particleShader.vert"
#define FRAG "../assets/shaders/particleShader.frag"

ParticleShader::ParticleShader() : AbstractShader(VERT, FRAG) {}

ParticleShader::~ParticleShader() = default;

void ParticleShader::setUniforms(const Camera &camera) {
    setUniform("uProjection", camera.getProj());
    setUniform("uTransform", transform);
    setUniform("uOffset", offset);
    setUniform("uColor", color);
}

void ParticleShader::setOffset(const Vector3f &offset) {
    this->offset = offset;
}

void ParticleShader::setColor(const Color &color) {
    this->color = color;
}

void ParticleShader::setTransform(const Matrix &transform) {
    this->transform = transform;
}
